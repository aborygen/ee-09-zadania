create database szkola;
use szkola;

create table uczen(
	idu int  not null primary key,
	imie varchar(20),
	nazwisko varchar(20),
	Pesel varchar (20),
	klasa varchar (20)
);
insert into uczen values 
(1, 'Jan','Kowal',93010189874,'1a'),
(2, 'Kuba','Długi',92020139874,'2a'),
(3, 'Ola','Kowalska',92020239874,'2a'),
(4, 'Paweł','Nowak',92050439874,'2a'),
(5, 'Piotr','Nowak',93101589874,'1a');

create table przedmiot(
	idp int  not null primary key,
	nazwa_przedmiotu varchar (20)
);

insert into przedmiot values 
(1, 'jezyk polski'),
(2, 'matematyka'),
(3, 'jezyk angielski'),
(4, 'biologia'),
(5, 'chemia');


create table ocena(
	ido int not null primary key ,
	idp int, 
	idu int  ,
	ocena int ,
	data_wystawienia date
);

Alter table ocena 
	add foreign key (idp) references przedmiot(idp),
	add  foreign key (idu) references uczen(idu);


insert into ocena values 
(1, 4, 1,4,20160404),
(2, 2, 2,3,20160404),
(3, 1, 2,2,20160404),
(4, 3, 3,4,20160404),
(5, 4, 1,5,20160505),
(6, 1, 1,5,20160505),
(7, 4, 2,3,20160505),
(8, 2, 1,3,20160606),
(9, 3, 3,5,20160606),
(10, 3, 3,3,20160606),
(11, 3, 1,4,20160606),
(12, 1, 2,5,20160606),
(13, 1, 2,1,20160606),
(14, 2, 3,3,20160606),
(15, 3, 2,5,20160607),
(16, 2, 3,3,20160607),
(17, 1, 2,5,20160607),
(18, 4, 3,4,20160608),
(19, 1, 1,5,20160608),
(20, 4, 3,1,20160608);



